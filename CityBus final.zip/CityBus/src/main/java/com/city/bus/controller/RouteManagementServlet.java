package com.city.bus.controller;

import com.city.bus.dao.RouteDao;
import com.city.bus.model.Route;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Time;
import java.util.List;

@WebServlet("/route-management")
public class RouteManagementServlet extends HttpServlet {
    private RouteDao routeDao = new RouteDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "add";
        }

        try {
            switch (action) {
                case "add":
                    if (request.getMethod().equals("POST")) {
                        String name = request.getParameter("name");
                        String startLocation = request.getParameter("start_location");
                        String endLocation = request.getParameter("end_location");
                        String startTime = request.getParameter("start_time");
                        String endTime = request.getParameter("end_time");
                        int number = Integer.parseInt(request.getParameter("number"));
                        boolean isHot = "on".equals(request.getParameter("is_hot"));

                        Route route = new Route(name, startLocation, endLocation, Time.valueOf(startTime + ":00"), Time.valueOf(endTime + ":00"), number, isHot);
                        routeDao.insertRoute(route);
                        response.sendRedirect(request.getContextPath() + "/route-management");
                        return;
                    }
                    break;
                case "edit":
                    String routeId = request.getParameter("id");
                    if (request.getMethod().equals("GET")) {
                        Route editRoute = routeDao.findById(Integer.parseInt(routeId));
                        request.setAttribute("editRoute", editRoute);
                    } else {
                        String name = request.getParameter("name");
                        String startLocation = request.getParameter("start_location");
                        String endLocation = request.getParameter("end_location");
                        String startTime = request.getParameter("start_time");
                        String endTime = request.getParameter("end_time");
                        int number = Integer.parseInt(request.getParameter("number"));
                        boolean isHot = "on".equals(request.getParameter("is_hot"));

                        Route route = new Route(Integer.parseInt(routeId), name, startLocation, endLocation, Time.valueOf(startTime + ":00"), Time.valueOf(endTime + ":00"), number, isHot);
                        routeDao.updateRoute(route);
                        response.sendRedirect(request.getContextPath() + "/route-management");
                        return;
                    }
                    break;
                case "delete":
                    routeId = request.getParameter("id");
                    routeDao.deleteRoute(Integer.parseInt(routeId));
                    response.sendRedirect(request.getContextPath() + "/route-management");
                    return;
            }

            List<Route> routes = routeDao.getAllRouteList();
            request.setAttribute("routes", routes);
            request.setAttribute("action", action);
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("route-management.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
