package com.city.bus.dao;

import com.city.bus.db.DBConnection;
import com.city.bus.model.Bus;
//import com.city.bus.model.Station;

import java.io.IOException;
import java.sql.*;
import java.util.*;

public class BusDao {
//    StationDao stationDao = new StationDao();

    private static final String INSERT_BUS_SQL = "INSERT INTO bus" +
            "  (bname, buspath,startDate, endDate ) VALUES " +
            " (?, ?, ?, ?);";

    private static final String SELECT_BUS_BY_ID = "SELECT * FROM bus WHERE id = ?";
    private static final String SELECT_ALL_BUS = "SELECT * FROM bus";
    private static final String DELETE_BUS_SQL = "DELETE FROM bus WHERE id = ?;";
    private static final String UPDATE_BUS_SQL = "UPDATE bus SET bname = ?, buspath = ?,startDate = ?, endDate = ? WHERE id = ?;";

    public void insertBus(Bus bus) throws SQLException, IOException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_BUS_SQL)) {
            preparedStatement.setString(1, bus.getName());
            preparedStatement.setString(2, bus.getBuspath());
            preparedStatement.setTime(3, Time.valueOf(bus.getStartDate()));
            preparedStatement.setTime(4, Time.valueOf(bus.getEndDate()));
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    public List<Route> findByStationName(String stationName) throws IOException {
//        List<Route> routes = new ArrayList<>();
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement stmt = connection.prepareStatement("SELECT r.* FROM routes r JOIN stations s ON r.id = s.route_id WHERE s.name = ?")) {
//            stmt.setString(1, stationName);
//            try (ResultSet rs = stmt.executeQuery()) {
//                while (rs.next()) {
//                    Route route = new Route();
//                    route.setId(rs.getInt("id"));
//                    route.setName(rs.getString("name"));
//                    route.setStartLocation(rs.getString("start_location"));
//                    route.setEndLocation(rs.getString("end_location"));
//                    route.setStartTime(rs.getTime("start_time").toLocalTime());
//                    route.setEndTime(rs.getTime("end_time").toLocalTime());
//                    route.setNumber(rs.getInt("number"));
//                    routes.add(route);
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return routes;
//    }

    public List<Bus> findByName(String bname) {
        List<Bus> routes = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM bus WHERE bname LIKE ?")) {
            statement.setString(1, "%" + bname + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
//                    String busName = resultSet.getString("bname");
//                    String startLocation = resultSet.getString("start_location");
//                    String endLocation = resultSet.getString("end_location");
//                    Time startTime = resultSet.getTime("start_time");
//                    Time endTime = resultSet.getTime("end_time");
//                    int number = resultSet.getInt("number");
//                    boolean isHot = resultSet.getBoolean("is_hot");
                    String name = resultSet.getString("bname");
                    String buspath = resultSet.getString("buspath");
                    Time startTime = resultSet.getTime("endDate");
                    Time endTime = resultSet.getTime("startDate");
                    Bus bus = new Bus(id, name, buspath, startTime, endTime);
//                    Bus route = new Bus(id, busName, startLocation, endLocation, startTime, endTime, number, isHot);
                    routes.add(bus);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return routes;
    }


    /**
     * find all neighbor station of station
     */
//    public Set<Station> findAllNeighborOfStation(String stationName) throws SQLException, IOException {
//        Set<Station> neighborStationSet = new HashSet<>();
//
//        List<Route> stationRoutes = findByStationName(stationName);
//        for (Route route : stationRoutes) {
//            List<Station> stations = stationDao.getStationsByRouteId(route.getId());
//            Station pre = null;
//            for (Station station : stations) {
//                if (station.getName().equals(stationName) && pre != null) {
//                    neighborStationSet.add(pre);
//                }
//                if (pre != null && pre.getName().equals(stationName)) {
//                    neighborStationSet.add(station);
//                }
//
//                pre = station;
//            }
//        }
//
//        return neighborStationSet;
//    }

//    public List<List<Station>> findTransferRoutes(String startStationName, String endStationName) throws SQLException, IOException {
//        List<List<Station>> result = new ArrayList<>();
//        Map<String, Boolean> traversalMap = new HashMap<>();
//        List<Station> path = new ArrayList<>();
//        traversalMap.put(startStationName, true);
//        findTransferRoutes(startStationName, endStationName, traversalMap, path, result);
//
//        for (List<Station> sts : result) {
//            sts.add(0, new Station(sts.get(0).getRouteId(), startStationName));
//        }
//
//        Map<Integer, Route> routeMap = getAllRoutes();
//
//        // fill route info
//        for (List<Station> sts : result) {
//            for (Station st : sts) {
//                st.setRoute(routeMap.get(st.getRouteId()));
//            }
//        }
//
//        // Define a Comparator to compare Lists based on their length
//        Comparator<List<Station>> listComparator = Comparator.comparingInt(List::size);
//
//        // Sort the list using the Comparator
//        result.sort(listComparator);
//        return result;
//    }
    public List<Bus> getAllBusList() throws SQLException, IOException {
        List<Bus> routes = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_BUS)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("bname");
                String buspath = resultSet.getString("buspath");
                Time startTime = resultSet.getTime("endDate");
                Time endTime = resultSet.getTime("startDate");
                Bus bus = new Bus(id, name, buspath, startTime, endTime);
                routes.add(bus);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return routes;
    }

    public Map<Integer, Bus> getAllBus() throws SQLException {
        Map<Integer, Bus> busMap = new HashMap<>();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM bus")) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("bname");
                String buspath = rs.getString("buspath");
                Time startTime = rs.getTime("endDate");
                Time endTime = rs.getTime("startDate");
                Bus bus = new Bus(id, name, buspath, startTime, endTime);
                busMap.put(id, bus);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return busMap;
    }
//
//    public List<Route> getAllHotRoutes() throws SQLException {
//        List<Route> routeMap = new ArrayList<>();
//        try (Connection conn = DBConnection.getConnection();
//             Statement stmt = conn.createStatement();
//             ResultSet rs = stmt.executeQuery("SELECT * FROM routes WHERE is_hot = 1")) {
//            while (rs.next()) {
//                int id = rs.getInt("id");
//                String name = rs.getString("name");
//                String startLocation = rs.getString("start_location");
//                String endLocation = rs.getString("end_location");
//                Time startTime = rs.getTime("start_time");
//                Time endTime = rs.getTime("end_time");
//                int number = rs.getInt("number");
//                Route route = new Route(id, name, startLocation, endLocation, startTime, endTime, number, true);
//                routeMap.add(route);
//            }
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        return routeMap;
//    }
//

//    private void findTransferRoutes(String startStationName, String endStationName, Map<String, Boolean> traversalMap, List<Station> path, List<List<Station>> result) throws SQLException, IOException {
//        Set<Station> neighborOfStartStation = findAllNeighborOfStation(startStationName);
//        for (Station station : neighborOfStartStation) {
//            if (traversalMap.get(station.getName()) != null && traversalMap.get(station.getName())) {
//                // already traversal, skip
//                continue;
//            }
//
//            // find the end station
//            if (station.getName().equals(endStationName)) {
//                List<Station> tmp = new ArrayList<>(path);
//                tmp.add(station);
//                result.add(tmp);
//                return;
//            }
//
//            traversalMap.put(station.getName(), true);
//            path.add(station);
//            findTransferRoutes(station.getName(), endStationName, traversalMap, path, result);
//            path.remove(station);
//            traversalMap.put(station.getName(), true);
//        }
//    }

    public Bus findById(int id) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM bus WHERE id = ?")) {
            stmt.setInt(1, id);
            try (ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    String busName = resultSet.getString("bname");
                    String buspath = resultSet.getString("buspath");
                    Time endDate = resultSet.getTime("endDate");
                    Time startDate = resultSet.getTime("startDate");
                    return new Bus(id, busName, buspath, endDate, startDate);
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding bus by ID", e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean deleteBus(int id) throws SQLException, IOException {
        boolean rowDeleted;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_BUS_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateBus(Bus bus) throws SQLException, IOException {
        boolean rowUpdated;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_BUS_SQL)) {
            statement.setString(1, bus.getName());
            statement.setString(2, bus.getBuspath());
            statement.setTime(3, Time.valueOf(bus.getStartDate()));
            statement.setTime(4, Time.valueOf(bus.getEndDate()));
            statement.setInt(5, bus.getId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

}
