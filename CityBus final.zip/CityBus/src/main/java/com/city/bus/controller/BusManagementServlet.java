package com.city.bus.controller;

import com.city.bus.dao.BusDao;
import com.city.bus.model.Bus;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Time;
import java.util.List;


@WebServlet("/bus-management")
public class BusManagementServlet extends HttpServlet {
    private BusDao busDao = new BusDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "add";
        }

        try {
            switch (action) {
                case "add":
                    if (request.getMethod().equals("POST")) {
                        String bname = request.getParameter("bname");
                        String buspath = request.getParameter("buspath");
                        String endDate = request.getParameter("endDate");
                        String startDate = request.getParameter("startDate");

                        Bus bus = new Bus(bname, buspath, Time.valueOf(endDate + ":00"), Time.valueOf(startDate + ":00"));
                        busDao.insertBus(bus);
                        response.sendRedirect(request.getContextPath() + "/bus-management");
                        return;
                    }
                    break;
                case "edit":
                    String busId = request.getParameter("id");
                    if (request.getMethod().equals("GET")) {
                        Bus editBus = busDao.findById(Integer.parseInt(busId));
                        request.setAttribute("editBus", editBus);
                    } else {
                        String bname = request.getParameter("bname");
                        String buspath = request.getParameter("buspath");
                        String endDate = request.getParameter("endDate");
                        String startDate = request.getParameter("startDate");

                        Bus bus = new Bus(Integer.parseInt(busId), bname, buspath, Time.valueOf(endDate + ":00"), Time.valueOf(startDate + ":00"));
                        busDao.updateBus(bus);

//                        routeDao.updateRoute(route);
                        response.sendRedirect(request.getContextPath() + "/bus-management");
                        return;
                    }
                    break;
                case "delete":
                    busId = request.getParameter("id");
                    busDao.deleteBus(Integer.parseInt(busId));
                    response.sendRedirect(request.getContextPath() + "/bus-management");
                    return;
            }

            List<Bus> routes = busDao.getAllBusList();
            request.setAttribute("routes", routes);
            request.setAttribute("action", action);
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("bus-management.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
