package com.city.bus.model;

import java.time.LocalDateTime;

public class Station {
    private int id;
    private int routeId;
    private String name;
    private int sequence;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Route route;

    public Station(int id, int routeId, String name, int sequence, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.routeId = routeId;
        this.name = name;
        this.sequence = sequence;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Station() {
    }

    public Station(int routeId, String name) {
        this.routeId = routeId;
        this.name = name;
    }

    public Station(Integer id, int routeId, String name, int sequence) {
        this.routeId = routeId;
        this.name = name;
        this.sequence = sequence;
        this.id = id;
    }

    public Station(int routeId, String name, int sequence) {
        this.routeId = routeId;
        this.name = name;
        this.sequence = sequence;
    }

    public int getId() {
        return id;
    }

    public int getRouteId() {
        return routeId;
    }

    public String getName() {
        return name;
    }

    public int getSequence() {
        return sequence;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }
}
