package com.city.bus.dao;

import com.city.bus.db.DBConnection;
import com.city.bus.model.Station;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StationDao {
    private static final String INSERT_STATION_SQL = "INSERT INTO stations" + "  (route_id, name, sequence) VALUES " +
            " (?, ?, ?);";

    private static final String SELECT_STATION_BY_ID = "select id,route_id,name,sequence from stations where id =?";
    private static final String SELECT_ALL_STATIONS = "select * from stations";
    private static final String SELECT_STATIONS_BY_ROUTE_ID = "select * from stations where route_id = ?";
    private static final String DELETE_STATION_SQL = "delete from stations where id = ?;";
    private static final String UPDATE_STATION_SQL = "update stations set route_id = ?,name= ?, sequence =? where id = ?;";

    public List<Station> getStationsByRouteId(int routeId) {
        Connection connection;
        PreparedStatement statement;
        ResultSet resultSet;
        List<Station> stations = new ArrayList<>();

        try {
            connection = DBConnection.getConnection();
            String sql = "SELECT * FROM stations WHERE route_id = ? ORDER BY sequence ASC ";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, routeId);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Station station = new Station();
                station.setId(resultSet.getInt("id"));
                station.setRouteId(resultSet.getInt("route_id"));
                station.setName(resultSet.getString("name"));
                station.setSequence(resultSet.getInt("sequence"));
                station.setCreatedAt(resultSet.getTimestamp("created_at").toLocalDateTime());
                station.setUpdatedAt(resultSet.getTimestamp("updated_at").toLocalDateTime());
                stations.add(station);
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }

        return stations;
    }

    public void insertStation(Station station) throws SQLException, IOException {
        System.out.println(INSERT_STATION_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_STATION_SQL)) {
            preparedStatement.setInt(1, station.getRouteId());
            preparedStatement.setString(2, station.getName());
            preparedStatement.setInt(3, station.getSequence());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Station getStationByID(Integer id) throws SQLException, IOException {
        Station station = null;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_STATION_BY_ID)) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int routeId = resultSet.getInt("route_id");
                String name = resultSet.getString("name");
                int sequence = resultSet.getInt("sequence");
                station = new Station(id, routeId, name, sequence);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return station;
    }

    public List<Station> selectAllStations() throws SQLException, IOException {
        List<Station> stations = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_STATIONS)) {
            System.out.println(preparedStatement);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int routeId = resultSet.getInt("route_id");
                String name = resultSet.getString("name");
                int sequence = resultSet.getInt("sequence");
                stations.add(new Station(id, routeId, name, sequence));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stations;
    }

    public List<Station> selectStationsByRouteID(int routeId) throws SQLException, IOException {
        List<Station> stations = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_STATIONS_BY_ROUTE_ID)) {
            preparedStatement.setInt(1, routeId);
            System.out.println(preparedStatement);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int sequence = resultSet.getInt("sequence");
                stations.add(new Station(id, routeId, name, sequence));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stations;
    }

    public boolean deleteStation(int id) throws SQLException, IOException {
        boolean rowDeleted;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_STATION_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateStation(Station station) throws SQLException, IOException {
        boolean rowUpdated;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_STATION_SQL)) {
            statement.setInt(1, station.getRouteId());
            statement.setString(2, station.getName());
            statement.setInt(3, station.getSequence());
            statement.setInt(4, station.getId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }
}

