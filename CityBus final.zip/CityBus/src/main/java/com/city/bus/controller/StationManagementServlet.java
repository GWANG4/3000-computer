package com.city.bus.controller;

import com.city.bus.dao.RouteDao;
import com.city.bus.dao.StationDao;
import com.city.bus.model.Route;
import com.city.bus.model.Station;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/station-management")
public class StationManagementServlet extends HttpServlet {
    private StationDao stationDao = new StationDao();
    private RouteDao routeDao = new RouteDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "add";
        }

        try {
            switch (action) {
                case "add":
                    if (request.getMethod().equals("POST")) {
                        int routeId = Integer.parseInt(request.getParameter("route_id"));
                        String name = request.getParameter("name");
                        int sequence = Integer.parseInt(request.getParameter("sequence"));

                        Station station = new Station(routeId, name, sequence);
                        stationDao.insertStation(station);
                        response.sendRedirect(request.getContextPath() + "/station-management");
                        return;
                    }

                    // Get all routes to display in the form
                    List<Route> routes = routeDao.getAllRouteList();
                    request.setAttribute("routes", routes);
                    break;

                case "edit":
                    int stationId = Integer.parseInt(request.getParameter("id"));

                    if (request.getMethod().equals("GET")) {
                        Station editStation = stationDao.getStationByID(stationId);
                        request.setAttribute("editStation", editStation);

                        // Get all routes to display in the form
                        List<Route> editRoutes = routeDao.getAllHotRoutes();
                        request.setAttribute("routes", editRoutes);
                    } else {
                        int routeId = Integer.parseInt(request.getParameter("route_id"));
                        String name = request.getParameter("name");
                        int sequence = Integer.parseInt(request.getParameter("sequence"));

                        Station station = new Station(stationId, routeId, name, sequence);
                        stationDao.updateStation(station);
                        response.sendRedirect(request.getContextPath() + "/station-management");
                        return;
                    }
                    break;

                case "delete":
                    stationId = Integer.parseInt(request.getParameter("id"));
                    stationDao.deleteStation(stationId);
                    response.sendRedirect(request.getContextPath() + "/station-management");
                    return;
            }

            // Get all stations to display in the table
            List<Station> stations = stationDao.selectAllStations();
            Map<Integer, Route> routeMap = routeDao.getAllRoutes();

            // fill route info
            for (Station st : stations) {
                st.setRoute(routeMap.get(st.getRouteId()));
            }

            request.setAttribute("stations", stations);
            request.setAttribute("action", action);
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("station-management.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
