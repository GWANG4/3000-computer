package com.city.bus.controller;

import com.city.bus.dao.AnnouncementDao;
import com.city.bus.model.Announcement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/announcements")
public class AnnouncementServlet extends HttpServlet {
    private AnnouncementDao announcementDao = new AnnouncementDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String announcementIdStr = request.getParameter("announcementId");

        try {
            if (announcementIdStr != null) {
                Announcement announcement = announcementDao.getAnnouncementById(Integer.parseInt(announcementIdStr));
                request.setAttribute("announcement", announcement);
            } else {
                List<Announcement> announcements = announcementDao.getAllAnnouncements();
                request.setAttribute("announcements", announcements);
            }

            request.getRequestDispatcher("announcements.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
