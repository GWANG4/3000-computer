package com.city.bus.dao;

import com.city.bus.db.DBConnection;
import com.city.bus.model.Question;
import com.city.bus.model.User;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class QuestionDao {
    public void addQuestion(Question question) throws SQLException {
        String query = "INSERT INTO questions (user_id, subject, message) VALUES (?, ?, ?)";
        try (PreparedStatement statement = DBConnection.getConnection().prepareStatement(query)) {
            statement.setInt(1, question.getUserId());
            statement.setString(2, question.getSubject());
            statement.setString(3, question.getMessage());
            statement.executeUpdate();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Question> getQuestions() {
        List<Question> questions = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT q.id, q.user_id, u.name as username, q.subject, q.message, q.created_at, q.updated_at, q.reply " +
                             "FROM questions q " +
                             "JOIN users u ON q.user_id = u.id " +
                             "ORDER BY q.created_at DESC")) {

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                int userId = rs.getInt("user_id");
                String username = rs.getString("username");
                String subject = rs.getString("subject");
                String message = rs.getString("message");
                LocalDateTime createdAt = rs.getTimestamp("created_at").toLocalDateTime();
                LocalDateTime updatedAt = rs.getTimestamp("updated_at").toLocalDateTime();
                String reply = rs.getString("reply");
                User user = new User(userId, username);
                Question question = new Question(id, user, subject, message, createdAt, updatedAt, reply);
                questions.add(question);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return questions;
    }


    public Question getQuestionById(int id) throws SQLException {
        String query = "SELECT * FROM questions WHERE id = ?";
        try (PreparedStatement statement = DBConnection.getConnection().prepareStatement(query)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Question(
                            resultSet.getInt("id"),
                            resultSet.getInt("user_id"),
                            resultSet.getString("subject"),
                            resultSet.getString("message"),
                            resultSet.getTimestamp("created_at").toLocalDateTime(),
                            resultSet.getTimestamp("updated_at").toLocalDateTime(),
                            resultSet.getString("reply")
                    );
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public void updateQuestion(Question question) throws SQLException {
        String query = "UPDATE questions SET reply = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        try (PreparedStatement statement = DBConnection.getConnection().prepareStatement(query)) {
            statement.setString(1, question.getReply());
            statement.setInt(2, question.getId());
            statement.executeUpdate();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
