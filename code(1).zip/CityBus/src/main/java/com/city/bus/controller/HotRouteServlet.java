package com.city.bus.controller;

import com.city.bus.dao.RouteDao;
import com.city.bus.model.Route;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/hot-routes")
public class HotRouteServlet extends HttpServlet {
    private RouteDao routeDao;

    @Override
    public void init() throws ServletException {
        super.init();
        routeDao = new RouteDao();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<Route> routes = routeDao.getAllHotRoutes();
            req.setAttribute("routes", routes);
            req.getRequestDispatcher("hot-routes.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
