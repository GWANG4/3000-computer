package com.city.bus.controller;

import com.city.bus.dao.UserDao;
import com.city.bus.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private UserDao userDAO;

    public void init() {
        userDAO = new UserDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Check if the email already exists in the database
        try {
            if (userDAO.emailAlreadyExists(email)) {
                request.setAttribute("error", "This email address is already registered. Please use a different email.");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
            }

            User user = new User(0, name, email, password, false);
            userDAO.insertUser(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("login.jsp");
    }
}
