package com.city.bus.dao;

import com.city.bus.db.DBConnection;
import com.city.bus.model.Station;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StationDao {
    public List<Station> getStationsByRouteId(int routeId) {
        Connection connection;
        PreparedStatement statement;
        ResultSet resultSet;
        List<Station> stations = new ArrayList<>();

        try {
            connection = DBConnection.getConnection();
            String sql = "SELECT * FROM stations WHERE route_id = ? ORDER BY sequence ASC ";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, routeId);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Station station = new Station();
                station.setId(resultSet.getInt("id"));
                station.setRouteId(resultSet.getInt("route_id"));
                station.setName(resultSet.getString("name"));
                station.setSequence(resultSet.getInt("sequence"));
                station.setCreatedAt(resultSet.getTimestamp("created_at").toLocalDateTime());
                station.setUpdatedAt(resultSet.getTimestamp("updated_at").toLocalDateTime());
                stations.add(station);
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }

        return stations;
    }
}
