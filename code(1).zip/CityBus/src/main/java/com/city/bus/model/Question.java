package com.city.bus.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class Question {
    private int id;
    private int userId;
    private String subject;
    private String message;
    private String reply;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private User user;

    public Question() {
    }

    public Question(int userId, String subject, String message) {
        this.userId = userId;
        this.subject = subject;
        this.message = message;
    }

    public Question(int id, int userId, String subject, String message, String reply, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.userId = userId;
        this.subject = subject;
        this.message = message;
        this.reply = reply;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Question(int id, int userId, String subject, String message, LocalDateTime createdAt, LocalDateTime updatedAt, String reply) {
        this.id = id;
        this.userId = userId;
        this.subject = subject;
        this.message = message;
        this.reply = reply;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Question(int id, User user, String subject, String message, LocalDateTime createdAt, LocalDateTime updatedAt, String reply) {
        this.id = id;
        this.userId = user.getId();
        this.user = user;
        this.subject = subject;
        this.message = message;
        this.reply = reply;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
