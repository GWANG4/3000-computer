package com.city.bus.controller;

import com.city.bus.dao.QuestionDao;
import com.city.bus.model.Question;
import com.city.bus.model.User;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/questions")
public class QuestionServlet extends HttpServlet {
    private QuestionDao questionDao = new QuestionDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String questionIdStr = request.getParameter("questionId");

        try {
            if (questionIdStr != null) {
                Question question = questionDao.getQuestionById(Integer.parseInt(questionIdStr));
                request.setAttribute("question", question);
            } else {
                List<Question> questions = questionDao.getQuestions();
                request.setAttribute("questions", questions);
            }

            request.getRequestDispatcher("questions.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
        String subject = req.getParameter("subject");
        String message = req.getParameter("message");

        try {
            User user = (User) req.getSession().getAttribute("user");
            questionDao.addQuestion(new Question(user.getId(), subject, message));

            resp.sendRedirect(req.getContextPath() + "/questions");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
