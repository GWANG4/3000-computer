package com.city.bus.controller;

import com.city.bus.dao.RouteDao;
import com.city.bus.dao.StationDao;
import com.city.bus.model.Route;
import com.city.bus.model.Station;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    private RouteDao routeDao;
    private StationDao stationDao;

    @Override
    public void init() throws ServletException {
        super.init();
        routeDao = new RouteDao();
        stationDao = new StationDao();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("home.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String startStationName = request.getParameter("startStationName");
        String endStationName = request.getParameter("endStationName");
        String routeName = request.getParameter("routeName");
        String stationName = request.getParameter("stationName");

        try {
            if (startStationName != null && endStationName != null) {
                // Search for transfer routes
                List<List<Station>> transferRoutes = routeDao.findTransferRoutes(startStationName, endStationName);
                request.setAttribute("transferRoutes", transferRoutes);
                request.setAttribute("showResult", true);
            } else if (routeName != null) {
                // Search for routes by name
                List<Route> routes = routeDao.findByName(routeName);
                request.setAttribute("routes", routes);
                request.setAttribute("showResult", true);
            } else if (stationName != null) {
                // Search for routes by station name
                List<Route> routes = routeDao.findByStationName(stationName);
                request.setAttribute("routes", routes);
                request.setAttribute("showResult", true);
            } else {
                request.setAttribute("showResult", false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("home.jsp").forward(request, response);
    }
}
