package com.city.bus.dao;

import com.city.bus.db.DBConnection;
import com.city.bus.model.Announcement;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AnnouncementDao {

    public List<Announcement> getAllAnnouncements() throws SQLException {
        List<Announcement> announcements = new ArrayList<>();
        String sql = "SELECT * FROM announcements";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Announcement announcement = new Announcement();
                announcement.setId(rs.getInt("id"));
                announcement.setTitle(rs.getString("title"));
                announcement.setMessage(rs.getString("message"));
                announcement.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                announcement.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
                announcements.add(announcement);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return announcements;
    }

    public Announcement getAnnouncementById(int id) throws SQLException {
        String sql = "SELECT * FROM announcements WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Announcement announcement = new Announcement();
                    announcement.setId(rs.getInt("id"));
                    announcement.setTitle(rs.getString("title"));
                    announcement.setMessage(rs.getString("message"));
                    announcement.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                    announcement.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
                    return announcement;
                } else {
                    return null;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void createAnnouncement(Announcement announcement) throws SQLException {
        String sql = "INSERT INTO announcements (title, message) VALUES (?, ?)";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, announcement.getTitle());
            stmt.setString(2, announcement.getMessage());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating announcement failed, no rows affected.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    announcement.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating announcement failed, no ID obtained.");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void updateAnnouncement(Announcement announcement) throws SQLException, IOException {
        String sql = "UPDATE announcements SET title=?, message=?, updated_at=NOW() WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, announcement.getTitle());
            stmt.setString(2, announcement.getMessage());
            stmt.setInt(3, announcement.getId());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Updating announcement failed, no rows affected.");
            }
        }
    }

    public void deleteAnnouncement(int id) throws SQLException {
        String sql = "DELETE FROM announcements WHERE id=?";
        try (PreparedStatement stmt = DBConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Deleting announcement failed, no rows affected.");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
