package com.city.bus.model;

import java.sql.Time;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Bus {
    private int id;
    private String bname;
    private String buspath;
    private LocalTime endDate;
    private LocalTime startDate;

    public Bus() {
    }

    public Bus(int id, String busName, String buspath, Time endDate, Time startDate) {
        this.id = id;
        this.bname = busName;
        this.buspath = buspath;
        this.endDate = endDate.toLocalTime();
        this.startDate = startDate.toLocalTime();
    }

    public Bus(String busName, String buspath, Time endDate, Time startDate) {
        this.bname = busName;
        this.buspath = buspath;
        this.endDate = endDate.toLocalTime();
        this.startDate = startDate.toLocalTime();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return bname;
    }


    public String getBuspath() {
        return buspath;
    }

    public LocalTime getEndDate() {
        return endDate;
    }

    public LocalTime getStartDate() {
        return startDate;
    }

//    public LocalDateTime getCreatedAt() {
//        return createdAt;
//    }
//
//    public LocalDateTime getUpdatedAt() {
//        return updatedAt;
//    }
//
//    public Integer getNumber() {
//        return number;
//    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.bname = name;
    }

//    public void setStartLocation(String startLocation) {
//        this.startLocation = startLocation;
//    }

    public void setBuspath(String buspath) {
        this.buspath = buspath;
    }

    public void setStartDate(LocalTime startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(LocalTime endDate) {
        this.endDate = endDate;
    }

//    public void setCreatedAt(LocalDateTime createdAt) {
//        this.createdAt = createdAt;
//    }
//
//    public void setUpdatedAt(LocalDateTime updatedAt) {
//        this.updatedAt = updatedAt;
//    }
//
//    public void setNumber(Integer number) {
//        this.number = number;
//    }
//
//    public boolean isHot() {
//        return isHot;
//    }
//
//    public void setHot(boolean hot) {
//        isHot = hot;
//    }
}
