package com.city.bus.controller;

import com.city.bus.dao.AnnouncementDao;
import com.city.bus.model.Announcement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/announcement-management")
public class AnnouncementManagementServlet extends HttpServlet {
    private AnnouncementDao announcementDao = new AnnouncementDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "add";
        }

        try {
            switch (action) {
                case "add":
                    if (request.getMethod().equals("POST")) {
                        String title = request.getParameter("title");
                        String message = request.getParameter("message");

                        Announcement announcement = new Announcement(title, message);
                        announcementDao.createAnnouncement(announcement);
                        response.sendRedirect(request.getContextPath() + "/announcement-management");
                        return;
                    }
                    break;
                case "edit":
                    String announcementId = request.getParameter("id");
                    if (request.getMethod().equals("GET")) {
                        Announcement editAnnouncement = announcementDao.getAnnouncementById(Integer.parseInt(announcementId));
                        request.setAttribute("editAnnouncement", editAnnouncement);
                    } else {
                        String title = request.getParameter("title");
                        String message = request.getParameter("message");

                        Announcement announcement = new Announcement(Integer.parseInt(announcementId), title, message);
                        announcementDao.updateAnnouncement(announcement);
                        response.sendRedirect(request.getContextPath() + "/announcement-management");
                        return;
                    }
                    break;
                case "delete":
                    announcementId = request.getParameter("id");
                    announcementDao.deleteAnnouncement(Integer.parseInt(announcementId));
                    response.sendRedirect(request.getContextPath() + "/announcement-management");
                    return;
            }

            List<Announcement> announcements = announcementDao.getAllAnnouncements();
            request.setAttribute("announcements", announcements);
            request.setAttribute("action", action);
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("announcement-management.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
