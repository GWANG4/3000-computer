package com.city.bus.controller;

import com.city.bus.dao.QuestionDao;
import com.city.bus.model.Question;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/question-management")
public class QuestionManagementServlet extends HttpServlet {
    private QuestionDao questionDao = new QuestionDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        try {
            switch (action) {
                case "edit":
                    String questionId = request.getParameter("id");
                    if (request.getMethod().equals("GET")) {
                        Question editQuestion = questionDao.getQuestionById(Integer.parseInt(questionId));
                        request.setAttribute("editQuestion", editQuestion);
                    } else {
                        String subject = request.getParameter("subject");
                        String message = request.getParameter("message");
                        String reply = request.getParameter("reply");

                        Question question = new Question(Integer.parseInt(questionId), subject, message, reply);
                        questionDao.updateQuestion(question);
                        response.sendRedirect(request.getContextPath() + "/question-management");
                        return;
                    }
                    break;
                case "delete":
                    questionId = request.getParameter("id");
                    questionDao.deleteQuestion(Integer.parseInt(questionId));
                    response.sendRedirect(request.getContextPath() + "/question-management");
                    return;
            }

            List<Question> questions = questionDao.getQuestions();
            request.setAttribute("questions", questions);
            request.setAttribute("action", action);
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("question-management.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
