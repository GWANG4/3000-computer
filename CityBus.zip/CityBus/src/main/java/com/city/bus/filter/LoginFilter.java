package com.city.bus.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginFilter implements Filter {
    public void init(FilterConfig config) throws ServletException {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
            throws ServletException, IOException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;

        // Skip the filter for CSS files
        if (request.getRequestURI().endsWith(".css")) {
            chain.doFilter(request, response);
            return;
        }

        // Skip the filter for login/register/logout requests
        String path = request.getRequestURI().substring(request.getContextPath().length());
        if (path.startsWith("/login") || path.startsWith("/register") || path.startsWith("/logout")) {
            chain.doFilter(request, response);
            return;
        }

        // Check whether the user is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            // User is not logged in, redirect to login page
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        } else {
            // User is logged in, continue with request processing
            chain.doFilter(request, response);
        }
    }

    public void destroy() {
    }
}
