package com.city.bus.controller;

import com.city.bus.dao.BusDao;
import com.city.bus.dao.RouteDao;
import com.city.bus.dao.StationDao;
import com.city.bus.model.Bus;
import com.city.bus.model.Route;
import com.city.bus.model.Station;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/home-page")
public class HomeServlet extends HttpServlet {
    private RouteDao routeDao;
    private StationDao stationDao;
    private BusDao busDao;

    @Override
    public void init() throws ServletException {
        super.init();
        routeDao = new RouteDao();
        busDao = new BusDao();
        stationDao = new StationDao();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("home.jsp").forward(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String bname = request.getParameter("bname");
        System.out.print(bname);
//        String endStationName = request.getParameter("endStationName");
        String routeName = request.getParameter("routeName");
        String stationName = request.getParameter("stationName");
//        System.out.print(startStationName);
//        System.out.print(endStationName);

        try {
            if (bname != null) {
                // Search for transfer routes
                List<Bus> bus = busDao.findByName(bname);
//                        .findTransferRoutes(startStationName, endStationName);

                System.out.print(bus);
                request.setAttribute("bus", bus);
                request.setAttribute("showResult", true);

            } else if (routeName != null) {
                // Search for routes by name
                List<Route> routes = routeDao.findByName(routeName);
                request.setAttribute("routes", routes);
                request.setAttribute("showResult", true);
            } else if (stationName != null) {
                // Search for routes by station name
                List<Route> routes = routeDao.findByStationName(stationName);
                request.setAttribute("routes", routes);
                request.setAttribute("showResult", true);
            } else {
                request.setAttribute("showResult", false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("home.jsp").forward(request, response);
    }
}
