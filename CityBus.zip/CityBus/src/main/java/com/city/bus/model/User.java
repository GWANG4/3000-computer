package com.city.bus.model;

public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private Boolean isManager;

    public User(int id, String name, String email, String password, Boolean isManager) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.isManager = isManager;
    }

    public User(int userId, String username) {
        this.id = userId;
        this.name = username;
    }

    public User( String name, String email, String password, boolean isManager) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.isManager = isManager;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public Boolean isManager() {
        return isManager;
    }
}
